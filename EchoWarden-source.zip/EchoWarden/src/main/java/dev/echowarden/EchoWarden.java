package dev.echowarden;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Warden;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class EchoWarden extends JavaPlugin implements Listener {

    private static final double TARGET_HP = 3000.0;
    private static final double DAMAGE_MULT = 1.5;
    private static final double TELEPORT_DIST = 18.0;
    private static final double FOLLOW_DIST = 4.0;

    private NamespacedKey ownerKey;
    private NamespacedKey sitKey;
    private Set<UUID> owners = new HashSet<>();

    private record Tgt(UUID id, long until) {}
    private final Map<UUID, Tgt> targets = new HashMap<>();

    @Override
    public void onEnable() {
        ownerKey = new NamespacedKey(this, "owner");
        sitKey = new NamespacedKey(this, "sit");
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 5L);
    }

    private boolean isTamed(Entity e) {
        return e instanceof Warden w && w.getPersistentDataContainer().has(ownerKey, PersistentDataType.STRING);
    }

    private UUID ownerOf(Warden w) {
        String s = w.getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        if (s == null) return null;
        try { return UUID.fromString(s); } catch (Exception ex) { return null; }
    }

    private boolean isSitting(Warden w) {
        return w.getPersistentDataContainer().has(sitKey, PersistentDataType.BYTE);
    }

    private Entity resolve(Entity damager) {
        if (damager instanceof Projectile p && p.getShooter() instanceof Entity s) return s;
        return damager;
    }

    // ---------- Taming / Sit ----------
    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        if (!(e.getRightClicked() instanceof Warden w)) return;
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        PersistentDataContainer pdc = w.getPersistentDataContainer();
        String o = pdc.get(ownerKey, PersistentDataType.STRING);

        if (o == null) {
            ItemStack it = p.getInventory().getItemInMainHand();
            if (it.getType() != Material.ECHO_SHARD) return;
            e.setCancelled(true);
            if (p.getGameMode() != GameMode.CREATIVE) it.setAmount(it.getAmount() - 1);
            tame(w, p);
            return;
        }

        e.setCancelled(true);
        if (!o.equals(p.getUniqueId().toString())) return;
        if (p.isSneaking()) setSit(w, !isSitting(w));
    }

    private void tame(Warden w, Player p) {
        w.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, p.getUniqueId().toString());
        w.setPersistent(true);
        w.setRemoveWhenFarAway(false);

        AttributeInstance hp = w.getAttribute(Attribute.MAX_HEALTH);
        if (hp != null) {
            try { hp.setBaseValue(TARGET_HP); }
            catch (IllegalArgumentException ex) { try { hp.setBaseValue(1024.0); } catch (Exception ignored) {} }
            w.setHealth(Math.min(hp.getValue(), w.getAttribute(Attribute.MAX_HEALTH).getValue()));
        }
        AttributeInstance atk = w.getAttribute(Attribute.ATTACK_DAMAGE);
        if (atk != null) atk.setBaseValue(atk.getBaseValue() * DAMAGE_MULT);

        w.customName(Component.text(p.getName() + "'s Warden", NamedTextColor.AQUA));
        w.setCustomNameVisible(true);
        w.clearAnger(p);
        w.setTarget(null);
        owners.add(p.getUniqueId());
    }

    private void setSit(Warden w, boolean sit) {
        if (sit) {
            w.getPersistentDataContainer().set(sitKey, PersistentDataType.BYTE, (byte) 1);
            w.setTarget(null);
            w.setAI(false);
        } else {
            w.getPersistentDataContainer().remove(sitKey);
            w.setAI(true);
        }
    }

    // ---------- Combat ----------
    private void setTarget(UUID owner, LivingEntity t) {
        targets.put(owner, new Tgt(t.getUniqueId(), System.currentTimeMillis() + 15000L));
    }

    private void darkness(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 200, 0, false, false, false));
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onHit(EntityDamageByEntityEvent e) {
        Entity victim = e.getEntity();
        Entity attacker = resolve(e.getDamager());

        // nobody (owner) hurts own warden
        if (isTamed(victim) && attacker instanceof Player) { e.setCancelled(true); return; }

        // tamed warden attacking
        if (e.getDamager() instanceof Warden w && isTamed(w)) {
            UUID ow = ownerOf(w);
            if (victim.getUniqueId().equals(ow)) { e.setCancelled(true); return; }
            if (victim instanceof Player pl) {
                Tgt t = targets.get(ow);
                if (t == null || !t.id().equals(pl.getUniqueId())) { e.setCancelled(true); return; }
                darkness(pl);
            }
            if (e.getCause() == EntityDamageEvent.DamageCause.SONIC_BOOM) {
                e.setDamage(e.getDamage() * DAMAGE_MULT);
            }
            return;
        }

        // owner hits something -> warden joins
        if (attacker instanceof Player a && owners.contains(a.getUniqueId())
                && victim instanceof LivingEntity lv && !isTamed(victim)) {
            setTarget(a.getUniqueId(), lv);
            if (lv instanceof Player vp) darkness(vp);
            return;
        }

        // owner attacked by a monster -> warden defends
        if (victim instanceof Player o && owners.contains(o.getUniqueId())
                && attacker instanceof Monster m && !(m instanceof Warden)) {
            setTarget(o.getUniqueId(), m);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Warden w && isTamed(w)) {
            AttributeInstance hp = w.getAttribute(Attribute.MAX_HEALTH);
            if (hp != null && hp.getValue() < TARGET_HP) {
                e.setDamage(e.getDamage() * hp.getValue() / TARGET_HP);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onTarget(EntityTargetLivingEntityEvent e) {
        if (!(e.getEntity() instanceof Warden w) || !isTamed(w)) return;
        LivingEntity t = e.getTarget();
        if (t == null) return;
        UUID ow = ownerOf(w);
        if (t.getUniqueId().equals(ow)) { e.setCancelled(true); return; }
        if (t instanceof Player) {
            Tgt tg = targets.get(ow);
            if (tg == null || !tg.id().equals(t.getUniqueId())) e.setCancelled(true);
        }
    }

    // no darkness pulse from tamed warden nearby
    @EventHandler(priority = EventPriority.HIGH)
    public void onPotion(EntityPotionEffectEvent e) {
        if (e.getCause() != EntityPotionEffectEvent.Cause.WARDEN) return;
        if (!(e.getEntity() instanceof Player p)) return;
        for (Entity n : p.getNearbyEntities(24, 24, 24)) {
            if (isTamed(n)) { e.setCancelled(true); return; }
        }
    }

    // ---------- Main loop ----------
    private void tick() {
        Set<UUID> found = new HashSet<>();
        for (World world : Bukkit.getWorlds()) {
            for (Warden w : world.getEntitiesByClass(Warden.class)) {
                if (!isTamed(w)) continue;
                UUID ow = ownerOf(w);
                if (ow == null) continue;
                found.add(ow);
                try { handle(w, ow); } catch (Exception ignored) {}
            }
        }
        owners = found;
    }

    private void handle(Warden w, UUID ow) {
        Player o = Bukkit.getPlayer(ow);
        if (isSitting(w) || o == null || !o.isOnline()) {
            if (w.hasAI()) w.setAI(false);
            return;
        }
        if (!w.hasAI()) w.setAI(true);

        LivingEntity tgt = resolveTarget(o, w);

        for (Player pl : w.getWorld().getPlayers()) {
            if (tgt == null || !pl.getUniqueId().equals(tgt.getUniqueId())) w.clearAnger(pl);
        }

        double dist = o.getWorld().equals(w.getWorld()) ? o.getLocation().distance(w.getLocation()) : Double.MAX_VALUE;

        if (tgt != null) {
            w.setAnger(tgt, 150);
            w.setTarget(tgt);
            if (dist > 40) w.teleport(o.getLocation());
            return;
        }

        if (w.getTarget() != null) w.setTarget(null);

        if (dist > TELEPORT_DIST) {
            w.teleport(o.getLocation());
        } else if (dist > FOLLOW_DIST) {
            w.getPathfinder().moveTo(o.getLocation(), 1.2);
        }
    }

    private LivingEntity resolveTarget(Player o, Warden w) {
        Tgt t = targets.get(o.getUniqueId());
        if (t != null) {
            Entity en = Bukkit.getEntity(t.id());
            if (en instanceof LivingEntity le && le.isValid() && !le.isDead()
                    && le.getWorld().equals(w.getWorld())
                    && System.currentTimeMillis() < t.until()
                    && le.getLocation().distance(w.getLocation()) < 40
                    && !(le instanceof Player p && (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR))) {
                return le;
            }
            targets.remove(o.getUniqueId());
        }
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : o.getNearbyEntities(16, 8, 16)) {
            if (e instanceof Monster m && !(m instanceof Warden) && m.isValid() && !m.isDead()) {
                double d = m.getLocation().distanceSquared(w.getLocation());
                if (d < bd) { bd = d; best = m; }
            }
        }
        return best;
    }
}
